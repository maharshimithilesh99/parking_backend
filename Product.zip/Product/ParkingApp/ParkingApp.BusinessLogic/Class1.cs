﻿namespace ParkingApp.BusinessLogic
{
    public class Class1
    {

    }
}
