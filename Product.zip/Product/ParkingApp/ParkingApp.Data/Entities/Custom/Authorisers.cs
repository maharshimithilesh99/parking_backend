
namespace ParkingApp.Data.Entities
{
	public partial class Authorisers
	{
        public string firstname { get; set; }
        public string lastname { get; set; }
    }
}

