﻿namespace ParkingApp.Utilities
{
    public class Class1
    {

    }
}
